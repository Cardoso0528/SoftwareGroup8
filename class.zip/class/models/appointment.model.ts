import { InferSchemaType, model, Schema } from "mongoose";

const appointmentSchema = new Schema(
    {
        service:{
            type: Schema.Types.ObjectID,
            required: true,
        },
        time:{
            type: String,
            required: true,
        },
        stylist:{
            type: String,
            required: true,
        },


    }
);

type Appointment = InferSchemaType<typeof appointmentSchema>;

export default model<Appointment>("Appointment", appointmentSchema);