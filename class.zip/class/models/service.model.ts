import { InferSchemaType, model, Schema } from "mongoose";


const serviceSchema = new Schema(
    {
        name:{
            type: String,
            required: true,
        },
        description:{
            type: String,
            required: true,
        },
        cost:{
            type: String,
            required: true,
        },

    }
);

type Service = InferSchemaType<typeof serviceSchema>;

export default model<Service>("Service", serviceSchema);