

class ClientAccount {
    username: string;
    firstname: string;
    lastname: string;
    email: string;
    usertype: string[];
    users_db: { [key: string]: any } = {}; // Simulate database for user accounts
    logged_in_users: Set<string> = new Set(); // Track users logged in



    // validate email address
    validate_email(email: string): boolean {
        const email_pattern = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z]+$/;
        return email_pattern.test(email);
    }

    // validate password (capital letter, special character, no spaces)
    validate_password_characters(password: string): boolean {
        let valid_password_characters = false;
        let uppercase_letter_found = false;
        let special_character_found = false;
        let space_detected = false;

        for (const character of password) {
            if (character === character.toUpperCase() && character !== character.toLowerCase()) {
                uppercase_letter_found = true;
            }
            if ("~`!@#$%^&*()_-+={[}]|\\:;\"'<,>.?/".includes(character)) {
                special_character_found = true;
            }
            if (character.trim() === '') {
                space_detected = true;
            }
        }

        if (uppercase_letter_found && special_character_found && !space_detected) {
            valid_password_characters = true;
        }
        return valid_password_characters;
    }

    // validate username
    validate_username(username: string): boolean {
        let valid_username_characters = true;
        let special_character_found = false;

        for (const character of username) {
            if (character.trim() === '') {
                valid_username_characters = false;
            }
            // username can have _ or - but no other special characters
            if ("~`!@#$%^&*()+={[}]|\\:;\"'<,>.?/".includes(character)) {
                special_character_found = true;
            }
        }
        return valid_username_characters && !special_character_found;
    }

    validate_first_name(first_name: string): boolean {
        let valid_first_name_characters = true;

        for (const character of first_name) {
            if ("~`!@#$%^&*()+={[}]|\\:;\"<,>.?/".includes(character)) {
                valid_first_name_characters = false;
            }
            if (/\d/.test(character)) {
                valid_first_name_characters = false;
            }
        }
        return valid_first_name_characters;
    }

    validate_last_name(last_name: string): boolean {
        let valid_last_name_characters = true;

        for (const character of last_name) {
            if ("~`!@#$%^&*()+={[}]|\\:;\"<,>.?/".includes(character)) {
                valid_last_name_characters = false;
            }
            if (/\d/.test(character)) {
                valid_last_name_characters = false;
            }
        }
        return valid_last_name_characters;
    }
    register_user(username: string, password: string, email: string, first_name: string, last_name: string): string {
        if (first_name.length < 1 || last_name.length < 1) {
            return "Error: first and last name must not be empty.";
        }
        if (!this.validate_first_name(first_name)) {
            return "Error: first name contains invalid characters.";
        }
        if (!this.validate_last_name(last_name)) {
            return "Error: last name contains invalid characters.";
        }
        if (!this.validate_email(email)) {
            return "Error: invalid email";
        }
        if (this.users_db[username]) {
            return "Error: username already exists.";
        }
        if (username.length < 8 || username.length > 20) {
            return "Error: username must be between 8 and 20 characters.";
        }
        if (!this.validate_username(username)) {
            return "Error: username cannot contain spaces or special characters.";
        }
        if (password.length < 8) {
            return "Error: password must be at least 8 characters.";
        }
        if (!this.validate_password_characters(password)) {
            return "Error: password must contain at least one capital letter and one special character and no spaces.";
        }
        if (this.users_db[email]) {
            return "Error: email already in use.";
        }
        this.users_db[username] = { password, fname: first_name, lname: last_name, email };
        return `User ${username} registered successfully.`;
    }

    is_logged_in(username: string): boolean {
        return this.logged_in_users.has(username);
    }

    login_user(username: string, password: string): string {
        if (!this.users_db[username]) {
            return "Error: Invalid username or password.";
        }
        if (this.users_db[username].password !== password) {
            return "Error: Invalid username or password.";
        }
        this.logged_in_users.add(username);
        return `User ${username} logged in successfully.`;
    }

    logout_user(username: string): string {
        if (this.is_logged_in(username)) {
            this.logged_in_users.delete(username);
            return `User ${username} logged out.`;
        }
        return "Error: Invalid username or password.";
    }

}

// used for some testing
const client_account = new ClientAccount();

console.log(client_account.register_user("john_doe", "Password123!", "john@example.com", "john", "doe"));  // Register user
console.log(client_account.login_user("john_doe", "Password123!"));  // Successful login
console.log(client_account.is_logged_in("john_doe"));  // Check login status (True)
console.log(client_account.logout_user("john_doe"));  // Logout user
console.log(client_account.is_logged_in("john_doe"));  // Check login status (False)
}

