var Service = /** @class */ (function () {
    function Service() {
    }
    Object.defineProperty(Service.prototype, "Name", {
        get: function () {
            return this.name;
        },
        set: function (name) {
            this.name = name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Service.prototype, "Description", {
        get: function () {
            return this.description;
        },
        set: function (description) {
            this.description = description;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Service.prototype, "Cost", {
        get: function () {
            return this.cost;
        },
        set: function (cost) {
            this.cost = cost;
        },
        enumerable: false,
        configurable: true
    });
    Service.prototype.validateCost = function (cost) {
        var pattern = new RegExp('/^\d+\.\d{2}$/');
        var validCost = true;
        for (var i = 0; i < cost.length; i++) {
            if (!isNaN(Number(cost[i])) && cost[i] !== '.') {
                validCost = false;
            }
        }
        if (!pattern.test(cost)) {
            validCost = false;
        }
        return validCost;
    };
    Service.prototype.validateDescription = function (description) {
        var validDescription = true;
        if (description.length > 500) {
            validDescription = false;
        }
        for (var _i = 0, description_1 = description; _i < description_1.length; _i++) {
            var char = description_1[_i];
            if ("~`!@#$%^*+={[}]|\\:;\"<>?/".includes(char)) {
                validDescription = false;
            }
        }
        return validDescription;
    };
    Service.prototype.validateName = function (name) {
        var validName = true;
        if (name.length > 50) {
            validName = false;
        }
        for (var _i = 0, name_1 = name; _i < name_1.length; _i++) {
            var char = name_1[_i];
            if ("~`!@#$%^*+={[}]|\\:;\"<>?/".includes(char)) {
                validName = false;
            }
        }
        return validName;
    };
    Service.prototype.addService = function (name, description, cost) {
        if (cost.length < 1 || name.length < 1 || description.length < 1) {
            return "Exceptional: No input";
        }
        if (!this.validateCost(cost)) {
            return "Error: Invalid cost";
        }
        if (!this.validateDescription(description)) {
            return "Error: Invalid description";
        }
        if (!this.validateName(name)) {
            return "Error: Invalid name";
        }
        return "Service added successfully";
    };
    return Service;
}());
var service = new Service();
var pattern = new RegExp('/^\d+\.\d{2}$/');
console.log(!pattern.test("60.00"));
console.log(service.addService("Hair Perm", "A permanent wave, commonly called a perm or permanent, is a hairstyle consisting of waves or curls set into the hair. The curls may last a number of months, hence the name.", "60.00"));
