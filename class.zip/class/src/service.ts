class Service {
     name: string;
     description: string;
     cost: string;

    public get Name(): string{
        return this.name;
    }

    public set Name(name: string){
        this.name = name;
    }

    public get Description(): string{
        return this.description;
    }

    public set Description(description: string){
        this.description = description;
    }

    public get Cost(): string{
        return this.cost;
    }

    public set Cost(cost: string) {
        this.cost = cost;
    }

    public validateCost(cost: string): boolean {
        const pattern = new RegExp ('/^\d+\.\d{2}$/');
        let validCost = true;
        for (let i = 0; i < cost.length; i++) {
            if (!isNaN(Number(cost[i])) && cost[i] !== '.') {
                validCost = false;
            }
        }
        if (!pattern.test(cost)) {
            validCost = false;
        }
        return validCost;
    }

    validateDescription(description: string): boolean {
        let validDescription = true;
        if (description.length > 500) {
            validDescription = false;
        }
        for (const char of description) {
            if ("~`!@#$%^*+={[}]|\\:;\"<>?/".includes(char)) {
                validDescription = false;
            }
        }
        return validDescription;
    }

    validateName(name: string): boolean {
        let validName = true;
        if (name.length > 50) {
            validName = false;
        }
        for (const char of name) {
            if ("~`!@#$%^*+={[}]|\\:;\"<>?/".includes(char)) {
                validName = false;
            }
        }
        return validName;
    }

    addService(name: string, description: string, cost: string): string {
        if (cost.length < 1 || name.length < 1 || description.length < 1) {
            return "Exceptional: No input";
        }
        if (!this.validateCost(cost)) {
            return "Error: Invalid cost";
        }
        if (!this.validateDescription(description)) {
            return "Error: Invalid description";
        }
        if (!this.validateName(name)) {
            return "Error: Invalid name";
        }
        return "Service added successfully";
    }
}

const service = new Service();
const pattern = new RegExp ('/^\d+\.\d{2}$/');
console.log(!pattern.test("60.00"))
console.log(service.addService("Hair Perm", "A permanent wave, commonly called a perm or permanent, is a hairstyle consisting of waves or curls set into the hair. The curls may last a number of months, hence the name.", "60.00"));

