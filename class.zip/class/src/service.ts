export class Service {
     name: string;
     description: string;
     cost: string;

    public get Name(): string{
        return this.name;
    }

    public set Name(name: string){
        this.name = name;
    }

    public get Description(): string{
        return this.description;
    }

    public set Description(description: string){
        this.description = description;
    }

    public get Cost(): string{
        return this.cost;
    }

    public set Cost(cost: string) {
        this.cost = cost;
    }

    public validateCost(cost: string): boolean {
        const pattern = /^\d+\.\d{2}$/;
        let validCost : boolean= true;
        for (let i = 0; i < cost.length; i++) {
            if (isNaN(Number(cost[i])) && cost[i] !== '.') {
                validCost = false;
                return validCost;
            }
        }
        if (!pattern.test(cost)) {
            validCost = false;
        }
        return validCost;
    }

    public validateDescription(description: string): boolean {
        let validDescription = true;
        if (description.length > 500) {
            validDescription = false;
        }
        for (const char of description) {
            if ("~`!@#$%^*+={[}]|\\:;\"<>?/".includes(char)) {
                validDescription = false;
            }
        }
        return validDescription;
    }

    public validateName(name: string): boolean {
        let validName = true;
        if (name.length > 50) {
            validName = false;
        }
        for (const char of name) {
            if ("~`!@#$%^*+={[}]|\\:;\"<>?/".includes(char)) {
                validName = false;
            }
        }
        return validName;
    }

    public addServiceTest(name: string, description: string, cost: string): string {
        if (cost.length < 1 || name.length < 1 || description.length < 1) {
            return "Exceptional: No input";
        }
        if (this.validateCost(cost) == false) {
            return "Error: Invalid cost";
        }
        if (this.validateDescription(description) == false) {
            return "Error: Invalid description";
        }
        if (this.validateName(name) == false) {
            return "Error: Invalid name";
        }
        return "Service added successfully";
    }

    public addService(name: string, description: string, cost: string): string {
        if (!name || !description || !cost) {
            return "Exceptional: No input";
        }
        if (!this.validateName(name)) return "Error: Invalid name";
        if (!this.validateDescription(description)) return "Error: Invalid description";
        if (!this.validateCost(cost)) return "Error: Invalid cost";

        this.Name = name;
        this.Description = description;
        this.Cost = cost;

        return "Service added successfully";
    }

    public editService(newName: string, newDescription: string, newCost: string): string {
        if (!newName || !newDescription || !newCost) {
            return "Exceptional: No input";
        }

        // Validate updates
        if (!this.validateName(newName)) return "Error: Invalid name";
        if (!this.validateDescription(newDescription)) return "Error: Invalid description";
        if (!this.validateCost(newCost)) return "Error: Invalid cost";

        // Apply updates
        this.Name = newName;
        this.Description = newDescription;
        this.Cost = newCost;
        
        return "Service updated successfully";
    }

    public delService(confirmationName: string): string {
        if (this.Name !== confirmationName) {
            return "Error: Service name mismatch";
        }

        // Clear service data
        this.Name = "";
        this.Description = "";
        this.Cost = "";
        
        return "Service deleted successfully";
    }
}
const pattern = /^\d+\.\d{2}$/;
const service = new Service();
let stuff: string = "60.00";
let valid: boolean = true;
for (let i = 0; i < stuff.length; i++) {
    if (isNaN(Number(stuff[i])) && stuff[i] !== '.') {
        console.log(stuff[i]);
        valid = false;
        break;
    }
}
if(!pattern.test(stuff)){
    valid = false;
}
console.log(valid);
console.log(service.addServiceTest("Hair Perm", "A permanent wave, commonly called a perm or permanent, is a hairstyle consisting of waves or curls set into the hair. The curls may last a number of months, hence the name.", "60.00"));

